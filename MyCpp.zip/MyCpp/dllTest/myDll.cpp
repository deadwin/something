#include "stdafx.h"
#include "myDll.h"
void myDll::print(){
	std::cout << "myDLL���Գɹ�" << std::endl;
}
int myDll::test(){
	return 10;
}
MYDLL_API int testFunc(void)
{
	return 42;
}