#ifdef MYDLL_EXPORTS
#define MYDLL_API __declspec(dllexport)
#else
#define MYDLL_API __declspec(dllimport)
#endif

#include <iostream>
class MYDLL_API myDll{
public:
	void print();
	int test();
};

MYDLL_API int testFunc(void);