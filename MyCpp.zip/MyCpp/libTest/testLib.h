#include <iostream>
class testLib{
public:
	void print();
};