#include "testLib.h"

using std::cout;

void testLib::print(){
	cout << "this is a lib test" <<std::endl;;
}

