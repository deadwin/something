#pragma once
static int DefaultLinkSize = 10;
#include "MyCode/LinearList/ListBase.h"
#include "MyCode/LinearList/LinkBase.h"
template<class Elem>class LinkTest :public ListBase<Elem>{
private:
	LinkBase<Elem>*					head;
	LinkBase<Elem>*					tail;
	LinkBase<Elem>*					fence;
	int										leftcnt;
	int										rightcnt;
	void init(){
		fence = tail = head = new LinkBase<Elem>;  //ע���ʼ����ʱ����ö�ָ��head�ĵ�ַ
		leftcnt = rightcnt = 0;
	}
	void removeall(){
		while (head!=NULL)
		{
			fence = head;
			head = head->next;
			delete fence;
		}
	}
public:
	LinkTest(int size = DefaultLinkSize){ init();  }

	~LinkTest(){ removeall();  }

	virtual void clear(){ removeall(); init(); }

	virtual bool insert(const Elem&item){ 
		fence->next = new LinkBase<Elem>(item, fence->next);
		if (tail == fence) tail = fence->next;
		rightcnt++;
		return true; }

	virtual bool append(const Elem&item){ 
		tail = tail->next = new LinkBase<Elem>(item, NULL);
		return true; }

	virtual bool remove(Elem&){ return true; }

	virtual void setStart(){
		fence = head;
		rightcnt += leftcnt;
		leftcnt = 0;
	}

	virtual void setEnd(){
		fence = tail;
		leftcnt += rightcnt;
		rightcnt = 0;
	}

	virtual void prev(){}

	virtual void next(){
		if (fence != tail) {
			fence = fence->next;
			leftcnt++;
			rightcnt--;
		}
	}

	virtual int leftLength() const{ return leftcnt; }

	virtual int rigthLength() const { return rightcnt; }

	virtual bool setPos(int pos){ return true; }

	virtual bool getValue(Elem&it)const { 
		if (rigthLength() == 0)return false;
		it = fence->next->element;
		return true; }

	virtual void print()const{}
};