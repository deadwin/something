#pragma once
//���Ա�ʵ��

#include"ListBase.h"
template<class Elem>
class ListTest :public ListBase<Elem> {
private:
	int maxSize;
	int fence;
	int listSize;
	Elem*listArray;
public:
	ListTest(int defaultSize = 10):
	maxSize(defaultSize),
		listSize(0),
		fence(0)
	{
		listArray = new Elem[maxSize];
	}
	~ListTest() {
		delete[]listArray;
	}
	void clear() {
		delete[]listArray;
		listSize = fence = 0;
		listArray = new Elem[maxSize];
	}
	bool insert(const Elem&item) {
		if (listSize == maxSize) return false;
		for (int i =listSize;i>fence;i--)
		{
			listArray[i] = listArray[i - 1];
		}
		listArray[fence] = item;
		listSize++;
		return true;
	}
	bool append(const Elem&item) {
		if (listSize == maxSize) return false;
		listArray[listSize++] = item;
		return true;
	}
	bool remove(Elem&item) {
		if (rigthLength()==0)
		{
			return false;
		}
		item = listArray[fence];  //���������Դ�һ��item������������ʲô��
		for (int i=fence;i<listSize-1;++i)
		{
			listArray[i] = listArray[i + 1];
		}
		listSize--;
		return true;
	}
	int rigthLength()const {
		return listSize - fence;
	}
	int leftLength()const {
		return fence;
	}
	void setStart() {
		fence = 0;
	}
	void setEnd() {
		fence = listSize;
	}
	void prev() {
		if (fence != 0)fence--;
	}
	void next() {
		if (fence <= listSize)fence++;  //�˴�<=
	}
	bool setPos(int pos) {
		if ((pos >= 0) && (pos <= listSize))fence = pos;
		return(pos >= 0) && (pos <= listSize);
	}
	//getValue������ôд��ɶ�ã�����Ϊ�ǲ���Ԫ�ء�
	bool getValue(Elem&item)const {
		if (rigthLength() == 0)return false;
		else {
			item = listArray[fence]; //��Ϊ�������Ա��е�ĳһ��Ԫ�ص���listArray[fence]��ֵ�𣿣�
			return true;
		}
	}
	void print()const {
		int temp = 0;
		cout << " < ";
		while (temp < fence)
		{
			cout << listArray[temp++] << " ";
		}
		cout << " | ";
		while (temp < listSize)
		{
			cout << listArray[temp++] << " ";
		}
		cout << " > \n";
	}
};