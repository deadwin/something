#pragma once

template<class Elem>class LinkBase {
public:
	Elem								element;
	LinkBase*						next;
	LinkBase(const Elem&elemval, LinkBase*nextval = NULL) {
		element = elemval;
		next = nextval;
	}
	LinkBase(LinkBase*nextval = NULL){
		next = nextval;
	}
};

